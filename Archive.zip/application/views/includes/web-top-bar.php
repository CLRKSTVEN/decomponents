<div id="topbar" class="d-none d-lg-flex align-items-center fixed-top">
    <div class="container d-flex align-items-center justify-content-between">
      <div class="d-flex align-items-center">
        <i class="icofont-graduate"></i> <?php echo $data[0]->SchoolName; ?>
      </div>
      <div class="d-flex align-items-center">
        <i class="icofont-phone"></i> Call Us <?php echo $data[0]->telNo; ?>
      </div>
    </div>
  </div>