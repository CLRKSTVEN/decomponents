<footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6">
            <div class="footer-info">
              <h3><?php echo $data[0]->SchoolName; ?></h3>
              <p>
                Address Here <br><br>
                <strong>Phone:</strong> <?php echo $data[0]->telNo; ?><br>
                <strong>Website:</strong> schoolwebsite.com<br>
				<strong>Email:</strong> info@domain.com<br>
              </p>
             
            </div>
          </div>


        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright 2020 <strong><span>Registered at the Intellectual Property Office of the Philippines with Certificate No. N-2020-00235</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        Powered by <a href="https://srmsportal.com/">SoftTech Solutions</a>
      </div>
    </div>
  </footer>