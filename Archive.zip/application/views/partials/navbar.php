<header class="decom-header">
    <div class="decom-container">
        <img src="<?php echo base_url('Pictures/DeComponents.jpeg'); ?>" alt="DeComponents Logo" class="decom-logo">
        <nav class="decom-nav">
            <div class="decom-container">
                <a href="<?php echo site_url('home'); ?>" class="decom-nav-link">HOME</a>
                <a href="<?php echo site_url('products'); ?>" class="decom-nav-link">PRODUCTS</a>
                <a href="<?php echo site_url('about'); ?>" class="decom-nav-link">ABOUT US</a>
                <a href="<?php echo site_url('tradables'); ?>" class="decom-nav-link">TRADABLES</a>
                <a href="<?php echo site_url('news'); ?>" class="decom-nav-link">NEWS</a>
                <a href="<?php echo site_url('contact'); ?>" class="decom-nav-link">CONTACT</a>
            </div>
        </nav>
    </div>
</header>
